package LWP::DebugFile;

our $VERSION = '6.77';

# legacy stub

1;
